
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import { Product, CartItem } from './types';

// Page Components
import Home from './pages/Home';
import Shop from './pages/Shop';
import AIDesigner from './pages/AIDesigner';
import Checkout from './pages/Checkout';
import Wishlist from './pages/Wishlist';

const STORAGE_KEY_WISHLIST = 'edenscape_wishlist';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);

  // Load wishlist from localStorage
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY_WISHLIST);
    if (stored) {
      try {
        setWishlist(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to load wishlist", e);
      }
    }
  }, []);

  // Save wishlist to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_WISHLIST, JSON.stringify(wishlist));
  }, [wishlist]);

  const addToCart = (product: Product, quantity: number = 1) => {
    setCart(prev => {
      const existing = prev.find(p => p.id === product.id);
      if (existing) {
        return prev.map(p => 
          p.id === product.id 
            ? { ...p, quantity: p.quantity + quantity } 
            : p
        );
      }
      return [...prev, { ...product, quantity }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(p => p.id !== id));
  };

  const clearCart = () => setCart([]);

  const toggleWishlist = (product: Product) => {
    setWishlist(prev => {
      const exists = prev.find(p => p.id === product.id);
      if (exists) {
        return prev.filter(p => p.id !== product.id);
      }
      return [...prev, product];
    });
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <Home onNavigate={setActiveTab} />;
      case 'shop':
        return (
          <Shop 
            onAddToCart={addToCart} 
            onToggleWishlist={toggleWishlist}
            wishlistIds={wishlist.map(p => p.id)}
          />
        );
      case 'ai-designer':
        return <AIDesigner onCheckoutProject={(project) => {
          addToCart({
            id: 'ai-project-' + Date.now(),
            name: `Landscape Project (${project.style})`,
            category: 'Service',
            price: 2500000 + (project.areaSize * 1000),
            image: project.designedImage || '',
            description: `Full redesign of ${project.areaSize}sqm garden in ${project.style} style.`
          }, 1);
          setActiveTab('cart');
        }} />;
      case 'cart':
        return <Checkout cart={cart} onRemove={removeFromCart} onClear={clearCart} onBack={() => setActiveTab('shop')} />;
      case 'wishlist':
        return (
          <Wishlist 
            wishlist={wishlist} 
            onRemove={toggleWishlist} 
            onAddToCart={(p) => {
              addToCart(p, 1);
              toggleWishlist(p);
            }} 
            onBack={() => setActiveTab('shop')} 
          />
        );
      default:
        return <Home onNavigate={setActiveTab} />;
    }
  };

  return (
    <Layout 
      activeTab={activeTab} 
      onTabChange={setActiveTab} 
      cartCount={cart.reduce((acc, item) => acc + item.quantity, 0)}
      wishlistCount={wishlist.length}
    >
      {renderContent()}
    </Layout>
  );
};

export default App;
