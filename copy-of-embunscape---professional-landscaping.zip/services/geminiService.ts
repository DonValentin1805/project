
import { GoogleGenAI } from "@google/genai";

export const generateLandscapeDesign = async (base64Image: string, style: string): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const prompt = `Redesign this outdoor garden space in a ${style} landscape style. 
    Add professional landscaping elements like lush greenery, decorative stones, pathways, and outdoor lighting. 
    Maintain the architectural structure of the house but transform the ground and vegetation. 
    High quality, photorealistic architectural visualization.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image.split(',')[1],
              mimeType: 'image/png'
            }
          },
          { text: prompt }
        ]
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("AI Generation Error:", error);
    return null;
  }
};
