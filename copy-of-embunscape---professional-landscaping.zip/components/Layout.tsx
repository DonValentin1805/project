import React, { useState, useEffect } from 'react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
  cartCount: number;
  wishlistCount: number;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange, cartCount, wishlistCount }) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex justify-between items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onTabChange('home')}>
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">E</div>
            <span className={`text-xl font-bold ${scrolled ? 'text-stone-900' : 'text-stone-900 md:text-white'}`}>EmbunScape AI</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            {['home', 'shop', 'ai-designer'].map((tab) => (
              <button
                key={tab}
                onClick={() => onTabChange(tab)}
                className={`capitalize font-medium transition-colors ${activeTab === tab ? 'text-emerald-600' : scrolled ? 'text-stone-600 hover:text-emerald-600' : 'text-stone-800 md:text-stone-100 hover:text-emerald-400'}`}
              >
                {tab.replace('-', ' ')}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button 
              onClick={() => onTabChange('wishlist')}
              className="relative p-2 bg-white rounded-full shadow-sm hover:bg-stone-50 transition-colors"
              title="Wishlist"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 ${activeTab === 'wishlist' ? 'text-rose-500 fill-rose-500' : 'text-stone-700'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">
                  {wishlistCount}
                </span>
              )}
            </button>
            
            <button 
              onClick={() => onTabChange('cart')}
              className="relative p-2 bg-white rounded-full shadow-sm hover:bg-stone-50 transition-colors"
              title="Cart"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-stone-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      <main className="flex-grow pt-0">
        {children}
      </main>

      <footer className="bg-stone-900 text-stone-400 py-12">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold">E</div>
                <span className="text-xl font-bold text-white tracking-tight">EmbunScape AI</span>
              </div>
              <p className="max-w-md">Transforming outdoor spaces with the power of artificial intelligence and professional landscape craftsmanship. Your dream garden is just a click away.</p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-6">Services</h4>
              <ul className="space-y-4">
                <li><a href="#" className="hover:text-emerald-500 transition-colors">AI Garden Design</a></li>
                <li><a href="#" className="hover:text-emerald-500 transition-colors">Plant Installation</a></li>
                <li><a href="#" className="hover:text-emerald-500 transition-colors">Maintenance Plans</a></li>
                <li><a href="#" className="hover:text-emerald-500 transition-colors">Bulk Supply</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-6">Company</h4>
              <ul className="space-y-4">
                <li><a href="#" className="hover:text-emerald-500 transition-colors">Our Portfolio</a></li>
                <li><a href="#" className="hover:text-emerald-500 transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-emerald-500 transition-colors">Reviews</a></li>
                <li><a href="#" className="hover:text-emerald-500 transition-colors">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-stone-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p>&copy; 2024 EmbunScape AI Landscaping. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;