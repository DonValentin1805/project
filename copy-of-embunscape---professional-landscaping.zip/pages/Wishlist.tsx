
import React from 'react';
import { Product } from '../types';

interface WishlistProps {
  wishlist: Product[];
  onRemove: (p: Product) => void;
  onAddToCart: (p: Product) => void;
  onBack: () => void;
}

const Wishlist: React.FC<WishlistProps> = ({ wishlist, onRemove, onAddToCart, onBack }) => {
  if (wishlist.length === 0) {
    return (
      <div className="pt-48 pb-24 flex flex-col items-center justify-center max-w-7xl mx-auto px-4">
        <div className="w-24 h-24 bg-stone-100 rounded-full flex items-center justify-center text-stone-300 mb-8">
          <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
        </div>
        <h2 className="text-3xl font-bold text-stone-900 mb-4">Your wishlist is empty</h2>
        <p className="text-stone-500 mb-10">Save your favorite plants and materials here for later.</p>
        <button 
          onClick={onBack}
          className="px-8 py-3 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-500 transition-all"
        >
          Explore Shop
        </button>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-4 md:px-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-bold text-stone-900 mb-2">My Wishlist</h1>
          <p className="text-stone-600">Saved items you're keeping an eye on.</p>
        </div>
        <button 
          onClick={onBack}
          className="text-emerald-600 font-bold hover:underline flex items-center gap-2"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
          Back to Shop
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {wishlist.map((product) => (
          <div key={product.id} className="group bg-white rounded-[2rem] overflow-hidden border border-stone-100 hover:shadow-xl transition-all duration-300">
            <div className="relative aspect-[4/5] overflow-hidden">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <button 
                onClick={() => onRemove(product)}
                className="absolute top-4 right-4 p-2 bg-rose-500 text-white rounded-full shadow-lg hover:bg-rose-600 transition-colors"
                title="Remove from wishlist"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
            
            <div className="p-8">
              <div className="mb-6">
                <h3 className="text-xl font-bold text-stone-900 mb-1">{product.name}</h3>
                <span className="text-emerald-600 font-bold">Rp {product.price.toLocaleString()}</span>
              </div>
              
              <button
                onClick={() => onAddToCart(product)}
                className="w-full py-4 bg-stone-900 text-white rounded-2xl hover:bg-emerald-600 transition-colors shadow-lg font-bold flex items-center justify-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg>
                Add to Cart
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Wishlist;
