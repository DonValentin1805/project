import React, { useState, useRef, useEffect } from 'react';
import { generateLandscapeDesign } from '../services/geminiService';

interface SavedProject {
  id: string;
  originalImage: string;
  designedImage: string;
  areaSize: number;
  style: string;
  timestamp: number;
}

interface AIDesignerProps {
  onCheckoutProject: (project: {
    originalImage: string;
    designedImage: string;
    areaSize: number;
    style: string;
  }) => void;
}

const STYLES = ['Modern Minimalist', 'Zen Garden', 'Tropical Oasis', 'Classic French', 'Desert Scape'];
const STORAGE_KEY = 'embunscape_saved_projects';

const AIDesigner: React.FC<AIDesignerProps> = ({ onCheckoutProject }) => {
  const [image, setImage] = useState<string | null>(null);
  const [designedImage, setDesignedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [areaSize, setAreaSize] = useState(25);
  const [selectedStyle, setSelectedStyle] = useState(STYLES[0]);
  const [savedProjects, setSavedProjects] = useState<SavedProject[]>([]);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const designerRef = useRef<HTMLDivElement>(null);

  // Load saved projects on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setSavedProjects(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to load saved projects", e);
      }
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setDesignedImage(null);
        setSaveStatus('idle');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!image) return;
    setIsGenerating(true);
    setSaveStatus('idle');
    try {
      const result = await generateLandscapeDesign(image, selectedStyle);
      setDesignedImage(result);
    } catch (err) {
      alert("Design generation failed. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveToGallery = () => {
    if (!image || !designedImage) return;
    
    setSaveStatus('saving');
    const newProject: SavedProject = {
      id: `proj-${Date.now()}`,
      originalImage: image,
      designedImage: designedImage,
      areaSize,
      style: selectedStyle,
      timestamp: Date.now()
    };

    const updated = [newProject, ...savedProjects];
    setSavedProjects(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    
    setTimeout(() => {
      setSaveStatus('saved');
    }, 600);
  };

  const handleExport = () => {
    if (!designedImage) return;
    const link = document.createElement('a');
    link.href = designedImage;
    link.download = `embunscape-${selectedStyle.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleLoadProject = (proj: SavedProject) => {
    setImage(proj.originalImage);
    setDesignedImage(proj.designedImage);
    setAreaSize(proj.areaSize);
    setSelectedStyle(proj.style);
    setSaveStatus('saved');
    
    // Scroll smoothly to the designer view
    designerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleDeleteProject = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedProjects.filter(p => p.id !== id);
    setSavedProjects(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-4 md:px-8">
      <div className="max-w-4xl mx-auto" ref={designerRef}>
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-stone-900 mb-4">AI Landscape Project</h1>
          <p className="text-stone-600">Upload your yard photo and let EmbunScape AI craft a professional redesign in seconds.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-24">
          {/* Controls */}
          <div className="space-y-8">
            <div className="bg-white p-8 rounded-[2rem] border border-stone-100 shadow-sm">
              <h3 className="text-lg font-bold mb-6">1. Upload Your Space</h3>
              <div 
                onClick={() => fileInputRef.current?.click()}
                className={`relative aspect-video rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center cursor-pointer overflow-hidden ${image ? 'border-emerald-500' : 'border-stone-200 hover:border-emerald-400 bg-stone-50'}`}
              >
                {image ? (
                  <img src={image} className="w-full h-full object-cover" alt="Source" />
                ) : (
                  <div className="text-center p-6">
                    <svg className="w-12 h-12 text-stone-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                    <p className="text-stone-500 font-medium">Click to upload photo of your yard</p>
                  </div>
                )}
                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
              </div>
            </div>

            <div className="bg-white p-8 rounded-[2rem] border border-stone-100 shadow-sm">
              <h3 className="text-lg font-bold mb-6">2. Configure Details</h3>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-stone-700 mb-2">Target Style</label>
                  <div className="grid grid-cols-2 gap-2">
                    {STYLES.map(style => (
                      <button
                        key={style}
                        onClick={() => setSelectedStyle(style)}
                        className={`px-4 py-3 rounded-xl text-xs font-bold transition-all border ${selectedStyle === style ? 'bg-emerald-50 border-emerald-500 text-emerald-700' : 'bg-white border-stone-200 text-stone-500 hover:border-stone-300'}`}
                      >
                        {style}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-stone-700 mb-2">Area Size ({areaSize} sqm)</label>
                  <input 
                    type="range" min="10" max="500" value={areaSize} 
                    onChange={(e) => setAreaSize(parseInt(e.target.value))}
                    className="w-full h-2 bg-stone-100 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={!image || isGenerating}
              className={`w-full py-5 rounded-2xl font-bold text-lg transition-all shadow-lg ${!image || isGenerating ? 'bg-stone-200 text-stone-400 cursor-not-allowed' : 'bg-stone-900 text-white hover:bg-emerald-700 shadow-emerald-900/10'}`}
            >
              {isGenerating ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                  Designing with AI...
                </span>
              ) : 'Generate Design'}
            </button>
          </div>

          {/* Result Display */}
          <div className="bg-stone-900 rounded-[2.5rem] p-4 min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden group">
            {designedImage ? (
              <>
                <img src={designedImage} className="w-full h-full object-cover rounded-[2rem]" alt="Result" />
                <div className="absolute bottom-8 left-8 right-8 space-y-3 animate-in fade-in slide-in-from-bottom-4">
                  <button 
                    onClick={() => onCheckoutProject({
                      originalImage: image!,
                      designedImage: designedImage!,
                      areaSize,
                      style: selectedStyle
                    })}
                    className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2"
                  >
                    Proceed to Quote
                  </button>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={handleSaveToGallery}
                      disabled={saveStatus !== 'idle'}
                      className={`py-3.5 backdrop-blur-md font-bold rounded-2xl transition-all border text-sm ${saveStatus === 'saved' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50' : 'bg-white/10 text-white border-white/20 hover:bg-white/20'}`}
                    >
                      {saveStatus === 'idle' && 'Save to Gallery'}
                      {saveStatus === 'saving' && 'Saving...'}
                      {saveStatus === 'saved' && (
                        <span className="flex items-center justify-center gap-1.5">
                          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                          Saved
                        </span>
                      )}
                    </button>
                    <button 
                      onClick={handleExport}
                      className="py-3.5 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/20 font-bold rounded-2xl transition-all text-sm flex items-center justify-center gap-2"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                      Export PNG
                    </button>
                  </div>
                </div>
              </>
            ) : isGenerating ? (
              <div className="text-center p-12">
                <div className="w-20 h-20 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
                <h3 className="text-white text-xl font-bold mb-2">Analyzing Photos</h3>
                <p className="text-stone-400">Gemini is rendering your dream garden...</p>
              </div>
            ) : (
              <div className="text-center p-12 opacity-50">
                <div className="w-20 h-20 bg-stone-800 rounded-3xl flex items-center justify-center text-emerald-600 mx-auto mb-6">
                  <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                </div>
                <h3 className="text-white text-xl font-bold">Waiting for Input</h3>
                <p className="text-stone-400">Configure and click Generate to see the magic.</p>
              </div>
            )}
          </div>
        </div>

        {/* Gallery Section */}
        <div className="border-t border-stone-200 pt-16">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-stone-900 mb-2">My Saved Designs</h2>
              <p className="text-stone-500">Click a design to view or modify it in the designer.</p>
            </div>
            {savedProjects.length > 0 && (
              <span className="px-4 py-1.5 bg-stone-100 rounded-full text-stone-600 font-bold text-sm">
                {savedProjects.length} Designs
              </span>
            )}
          </div>

          {savedProjects.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {savedProjects.map((proj) => (
                <div 
                  key={proj.id} 
                  className="group bg-white rounded-[2rem] overflow-hidden border border-stone-100 hover:shadow-xl transition-all duration-300 cursor-pointer"
                  onClick={() => handleLoadProject(proj)}
                >
                  <div className="relative aspect-video overflow-hidden">
                    <img 
                      src={proj.designedImage} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                      alt={proj.style} 
                    />
                    <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                       <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          const link = document.createElement('a');
                          link.href = proj.designedImage;
                          link.download = `embunscape-gallery-${proj.id}.png`;
                          document.body.appendChild(link);
                          link.click();
                          document.body.removeChild(link);
                        }}
                        className="w-10 h-10 bg-white/90 backdrop-blur-md rounded-xl flex items-center justify-center text-stone-400 hover:text-emerald-600 transition-colors shadow-lg"
                        title="Download"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                      </button>
                      <button 
                        onClick={(e) => handleDeleteProject(proj.id, e)}
                        className="w-10 h-10 bg-white/90 backdrop-blur-md rounded-xl flex items-center justify-center text-stone-400 hover:text-red-500 transition-colors shadow-lg"
                        title="Delete"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                      </button>
                    </div>
                    <div className="absolute bottom-4 left-4">
                      <span className="px-3 py-1 bg-emerald-600 text-white rounded-full text-[10px] font-bold uppercase tracking-wider">
                        {proj.style}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between items-center mb-1">
                      <h4 className="font-bold text-stone-900">Garden Project</h4>
                      <span className="text-emerald-600 font-bold text-sm">{proj.areaSize} sqm</span>
                    </div>
                    <p className="text-stone-400 text-xs">{new Date(proj.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-stone-50 rounded-[2.5rem] border-2 border-dashed border-stone-200 p-20 text-center">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-stone-300 mx-auto mb-6 shadow-sm">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
              </div>
              <h3 className="text-xl font-bold text-stone-800 mb-2">No saved designs yet</h3>
              <p className="text-stone-500 max-w-xs mx-auto">Generate a new landscape design above and save it here to build your collection.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIDesigner;