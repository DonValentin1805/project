
import React, { useState } from 'react';
import { Product } from '../types';

const MOCK_PRODUCTS: Product[] = [
  { id: '1', name: 'Monstera Deliciosa', category: 'Plant', price: 150000, image: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&q=80&w=400', description: 'Swiss Cheese Plant, perfect for tropical vibes.' },
  { id: '2', name: 'River Stones (10kg)', category: 'Material', price: 85000, image: 'https://images.unsplash.com/photo-1502481851512-e9e2529bbbf9?auto=format&fit=crop&q=80&w=400', description: 'Smooth grey river stones for decorative pathways.' },
  { id: '3', name: 'Japanese Maple', category: 'Plant', price: 750000, image: 'https://images.unsplash.com/photo-1544253303-3990818f95c8?auto=format&fit=crop&q=80&w=400', description: 'Elegant red maple tree for focus points.' },
  { id: '4', name: 'Wood Chips Mulch', category: 'Material', price: 45000, image: 'https://images.unsplash.com/photo-1596431109003-88c9629b357e?auto=format&fit=crop&q=80&w=400', description: 'High-quality cedar mulch for soil moisture.' },
  { id: '5', name: 'Snake Plant XL', category: 'Plant', price: 220000, image: 'https://images.unsplash.com/photo-1593482892290-f54927ae1bf7?auto=format&fit=crop&q=80&w=400', description: 'Low maintenance air purifying plant.' },
  { id: '6', name: 'Decorative Outdoor Lantern', category: 'Material', price: 350000, image: 'https://images.unsplash.com/photo-1517527634825-45d625b0f443?auto=format&fit=crop&q=80&w=400', description: 'Solar powered weather-resistant lantern.' },
];

interface ShopProps {
  onAddToCart: (p: Product, q: number) => void;
  onToggleWishlist: (p: Product) => void;
  wishlistIds: string[];
}

const ProductCard: React.FC<{
  product: Product;
  isWishlisted: boolean;
  onAddToCart: (p: Product, q: number) => void;
  onToggleWishlist: (p: Product) => void;
}> = ({ product, isWishlisted, onAddToCart, onToggleWishlist }) => {
  const [quantity, setQuantity] = useState(1);

  const increment = () => setQuantity(q => q + 1);
  const decrement = () => setQuantity(q => Math.max(1, q - 1));

  return (
    <div className="group bg-white rounded-[2rem] overflow-hidden border border-stone-100 hover:shadow-2xl hover:shadow-stone-200/50 transition-all duration-300">
      <div className="relative aspect-[4/5] overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4">
          <span className="px-3 py-1 bg-white/90 backdrop-blur-md rounded-full text-xs font-bold text-emerald-600 border border-stone-100">
            {product.category}
          </span>
        </div>
        <button 
          onClick={() => onToggleWishlist(product)}
          className="absolute top-4 right-4 p-2 bg-white/90 backdrop-blur-md rounded-full shadow-sm hover:bg-white transition-colors group/wish"
          title={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className={`h-5 w-5 transition-colors ${isWishlisted ? 'text-rose-500 fill-rose-500' : 'text-stone-400 group-hover/wish:text-rose-400'}`} 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
        </button>
      </div>
      
      <div className="p-8">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-bold text-stone-900 mb-1">{product.name}</h3>
            <p className="text-stone-500 text-sm leading-relaxed line-clamp-2">{product.description}</p>
          </div>
        </div>
        
        <div className="flex items-center justify-between mb-6">
          <span className="text-2xl font-bold text-emerald-600">
            Rp {product.price.toLocaleString()}
          </span>
          <div className="flex items-center bg-stone-50 rounded-xl p-1 border border-stone-100">
            <button 
              onClick={decrement}
              className="w-8 h-8 flex items-center justify-center text-stone-400 hover:text-emerald-600 transition-colors"
            >
              -
            </button>
            <span className="w-8 text-center font-bold text-stone-700">{quantity}</span>
            <button 
              onClick={increment}
              className="w-8 h-8 flex items-center justify-center text-stone-400 hover:text-emerald-600 transition-colors"
            >
              +
            </button>
          </div>
        </div>

        <button
          onClick={() => {
            onAddToCart(product, quantity);
            setQuantity(1); // Reset local quantity after adding
          }}
          className="w-full flex items-center justify-center gap-2 py-4 bg-stone-900 text-white rounded-2xl hover:bg-emerald-600 transition-colors shadow-lg shadow-stone-900/10 font-bold"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
          </svg>
          Add to Cart
        </button>
      </div>
    </div>
  );
};

const Shop: React.FC<ShopProps> = ({ onAddToCart, onToggleWishlist, wishlistIds }) => {
  const [filter, setFilter] = useState<'All' | 'Plant' | 'Material'>('All');

  const filteredProducts = MOCK_PRODUCTS.filter(p => filter === 'All' || p.category === filter);

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-4 md:px-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-bold text-stone-900 mb-2">Plant & Materials Shop</h1>
          <p className="text-stone-600">Quality supplies for your landscaping needs.</p>
        </div>
        
        <div className="flex bg-stone-100 p-1.5 rounded-2xl">
          {['All', 'Plant', 'Material'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f as any)}
              className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${filter === f ? 'bg-white text-emerald-600 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}
            >
              {f}s
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProducts.map((product) => (
          <ProductCard 
            key={product.id}
            product={product}
            isWishlisted={wishlistIds.includes(product.id)}
            onAddToCart={onAddToCart}
            onToggleWishlist={onToggleWishlist}
          />
        ))}
      </div>
    </div>
  );
};

export default Shop;
