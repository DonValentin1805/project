import React from 'react';

interface HomeProps {
  onNavigate: (tab: string) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1558904541-efa8c1965f1e?auto=format&fit=crop&q=80&w=2000" 
            alt="Beautiful garden" 
            className="w-full h-full object-cover brightness-50"
          />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 w-full text-white">
          <div className="max-w-3xl">
            <span className="inline-block px-4 py-1.5 bg-emerald-600/30 backdrop-blur-md rounded-full text-emerald-300 font-semibold text-sm mb-6 border border-emerald-500/30">
              Transforming Nature with AI
            </span>
            <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight">
              Design Your Perfect Garden in Seconds.
            </h1>
            <p className="text-xl md:text-2xl text-stone-200 mb-10 leading-relaxed">
              Upload a photo of your backyard and let our AI create a professional landscape design tailored to your space.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => onNavigate('ai-designer')}
                className="px-8 py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-bold text-lg transition-all transform hover:scale-105 shadow-xl shadow-emerald-900/20"
              >
                Try AI Designer
              </button>
              <button 
                onClick={() => onNavigate('shop')}
                className="px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 text-white rounded-2xl font-bold text-lg transition-all"
              >
                Browse Shop
              </button>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-12 left-0 right-0 flex justify-center animate-bounce">
          <svg className="w-8 h-8 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </section>

      {/* New Large Photo Feature Section */}
      <section className="py-24 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2 space-y-8 animate-in fade-in slide-in-from-left-8 duration-700">
              <h2 className="text-4xl md:text-5xl font-bold text-stone-900 leading-tight">
                Crafting Serenity with Professional <span className="text-emerald-600">Precision.</span>
              </h2>
              <p className="text-lg text-stone-600 leading-relaxed">
                At EmbunScape, we believe every morning should start with the freshness of nature. Our signature designs focus on creating sustainable, breathtaking environments that harmonize with your home's architecture.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="border-l-4 border-emerald-500 pl-4">
                  <h4 className="font-bold text-stone-900">500+ Projects</h4>
                  <p className="text-sm text-stone-500">Delivered nationwide</p>
                </div>
                <div className="border-l-4 border-emerald-500 pl-4">
                  <h4 className="font-bold text-stone-900">Expert Care</h4>
                  <p className="text-sm text-stone-500">Certified horticulturists</p>
                </div>
              </div>
              <button 
                onClick={() => onNavigate('ai-designer')}
                className="group flex items-center gap-2 font-bold text-emerald-600 hover:text-emerald-700 transition-all"
              >
                Start your transformation
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
              </button>
            </div>
            <div className="lg:w-1/2 relative group animate-in fade-in slide-in-from-right-8 duration-700">
              <div className="absolute -inset-4 bg-emerald-50 rounded-[3rem] -z-10 group-hover:bg-emerald-100 transition-colors"></div>
              <img 
                src="https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&q=80&w=1200" 
                alt="Modern garden landscape" 
                className="w-full rounded-[2.5rem] shadow-2xl object-cover aspect-[4/5] lg:aspect-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24 bg-stone-50">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-stone-900 mb-4">Why EmbunScape?</h2>
            <p className="text-stone-600 max-w-2xl mx-auto">We combine traditional horticultural expertise with modern technology to deliver stunning results.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 bg-white rounded-3xl border border-stone-100 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 mb-6">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              </div>
              <h3 className="text-xl font-bold mb-4">Instant AI Design</h3>
              <p className="text-stone-600">See your garden's potential immediately. No more guessing how plants will look together.</p>
            </div>
            
            <div className="p-8 bg-white rounded-3xl border border-stone-100 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 mb-6">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04M12 21a9.003 9.003 0 008.367-5.658M12 21a9.003 9.003 0 01-8.367-5.658M12 21c-4.97 0-9-4.03-9-9s4.03-9 9-9 9 4.03 9 9-4.03 9-9 9z" /></svg>
              </div>
              <h3 className="text-xl font-bold mb-4">3-Month Warranty</h3>
              <p className="text-stone-600">All our plants and installations are guaranteed for 90 days. We ensure your green space thrives.</p>
            </div>
            
            <div className="p-8 bg-white rounded-3xl border border-stone-100 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 mb-6">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
              </div>
              <h3 className="text-xl font-bold mb-4">Expert Maintenance</h3>
              <p className="text-stone-600">Professional care packages available to keep your garden in pristine condition year-round.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Portfolio */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-8 text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Recent Transformations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="group relative overflow-hidden rounded-3xl aspect-[4/3]">
                <img 
                  src={`https://picsum.photos/seed/${i + 10}/800/600`} 
                  alt="Project" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-8 text-left">
                  <div>
                    <h4 className="text-white text-xl font-bold">Urban Oasis Project</h4>
                    <p className="text-stone-300">Modern Minimalist Style</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;