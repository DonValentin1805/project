
import React, { useState, useMemo } from 'react';
import { CartItem, ServiceOptions, PRICING_CONSTANTS } from '../types';

interface CheckoutProps {
  cart: CartItem[];
  onRemove: (id: string) => void;
  onClear: () => void;
  onBack: () => void;
}

const Checkout: React.FC<CheckoutProps> = ({ cart, onRemove, onClear, onBack }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [distance, setDistance] = useState(5);
  const [options, setOptions] = useState<ServiceOptions>({
    shipping: true,
    maintenance: false,
    warranty: true,
    installation: false,
  });

  const cartTotal = useMemo(() => cart.reduce((sum, p) => sum + (p.price * p.quantity), 0), [cart]);
  
  const shippingFee = useMemo(() => {
    return options.shipping ? distance * PRICING_CONSTANTS.SHIPPING_KM_RATE : 0;
  }, [options.shipping, distance]);

  const additionalFees = useMemo(() => {
    let fees = shippingFee;
    if (options.maintenance) fees += PRICING_CONSTANTS.MAINTENANCE_FEE;
    if (options.warranty) fees += PRICING_CONSTANTS.WARRANTY_FEE;
    if (options.installation) fees += PRICING_CONSTANTS.INSTALLATION_BASE;
    return fees;
  }, [options, shippingFee]);

  const grandTotal = cartTotal + additionalFees;

  const toggleOption = (key: keyof ServiceOptions) => {
    setOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleCompleteOrder = async () => {
    setIsSubmitting(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Simulate sending email
    const placeholderEmail = "customer@example.com";
    console.log(`[SIMULATION] Sending order confirmation email to ${placeholderEmail}...`);
    console.log(`[SIMULATION] Order details: Total Rp ${grandTotal.toLocaleString()}, Items: ${cart.length}`);
    
    setIsSubmitting(false);
    setIsSuccess(true);
  };

  const handleFinish = () => {
    onClear();
    onBack();
  };

  if (isSuccess) {
    return (
      <div className="pt-48 pb-24 flex flex-col items-center justify-center max-w-7xl mx-auto px-4 animate-in fade-in zoom-in duration-500">
        <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 mb-8">
          <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h2 className="text-4xl font-bold text-stone-900 mb-4">Order Placed Successfully!</h2>
        <p className="text-stone-500 text-lg mb-2">Thank you for choosing EmbunScape AI.</p>
        <p className="text-emerald-600 font-medium mb-10 px-6 py-2 bg-emerald-50 rounded-full border border-emerald-100">
          A confirmation email has been sent to <span className="font-bold">customer@example.com</span>
        </p>
        <button 
          onClick={handleFinish}
          className="px-10 py-4 bg-stone-900 text-white font-bold rounded-2xl hover:bg-emerald-600 transition-all shadow-xl"
        >
          Return to Shop
        </button>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="pt-48 pb-24 flex flex-col items-center justify-center max-w-7xl mx-auto px-4">
        <div className="w-24 h-24 bg-stone-100 rounded-full flex items-center justify-center text-stone-300 mb-8">
          <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>
        </div>
        <h2 className="text-3xl font-bold text-stone-900 mb-4">Your cart is empty</h2>
        <p className="text-stone-500 mb-10">Add some plants or start an AI project to see them here.</p>
        <button 
          onClick={onBack}
          className="px-8 py-3 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-500 transition-all"
        >
          Go to Shop
        </button>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-4 md:px-8">
      <h1 className="text-4xl font-bold text-stone-900 mb-12 text-center">Checkout Summary</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-[2rem] border border-stone-100 shadow-sm">
            <div className="flex justify-between items-center mb-8 pb-4 border-b border-stone-50">
              <h3 className="text-xl font-bold">Your Selection</h3>
              <button 
                onClick={onClear} 
                disabled={isSubmitting}
                className="text-sm text-red-500 font-bold hover:underline disabled:opacity-50"
              >
                Clear All
              </button>
            </div>
            <div className="space-y-6">
              {cart.map((item) => (
                <div key={item.id} className="flex gap-6 p-4 rounded-2xl hover:bg-stone-50 transition-colors">
                  <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0">
                    <img src={item.image} className="w-full h-full object-cover" alt={item.name} />
                  </div>
                  <div className="flex-grow">
                    <div className="flex justify-between mb-1">
                      <h4 className="font-bold text-lg">{item.name}</h4>
                      <button 
                        onClick={() => onRemove(item.id)} 
                        disabled={isSubmitting}
                        className="text-stone-300 hover:text-red-500 transition-colors disabled:opacity-0"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                      </button>
                    </div>
                    <p className="text-stone-500 text-sm mb-2">{item.description}</p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <span className="text-stone-400 text-sm">Qty:</span>
                        <span className="font-bold text-stone-700">{item.quantity}</span>
                      </div>
                      <span className="text-emerald-600 font-bold">Rp {(item.price * item.quantity).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-8 rounded-[2rem] border border-stone-100 shadow-sm">
            <h3 className="text-xl font-bold mb-8">Service Customization (Optional)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <button 
                onClick={() => toggleOption('shipping')}
                disabled={isSubmitting}
                className={`p-6 rounded-[2rem] border-2 transition-all text-left flex items-start gap-4 ${options.shipping ? 'bg-emerald-50 border-emerald-500' : 'border-stone-100 hover:border-emerald-200'}`}
              >
                <div className={`p-3 rounded-2xl ${options.shipping ? 'bg-emerald-600 text-white' : 'bg-stone-100 text-stone-400'}`}>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                </div>
                <div>
                  <h4 className={`font-bold ${options.shipping ? 'text-emerald-900' : 'text-stone-900'}`}>Expedited Shipping</h4>
                  <p className="text-xs text-stone-500 mt-1">Rp {PRICING_CONSTANTS.SHIPPING_KM_RATE.toLocaleString()} / km</p>
                </div>
              </button>

              <button 
                onClick={() => toggleOption('maintenance')}
                disabled={isSubmitting}
                className={`p-6 rounded-[2rem] border-2 transition-all text-left flex items-start gap-4 ${options.maintenance ? 'bg-emerald-50 border-emerald-500' : 'border-stone-100 hover:border-emerald-200'}`}
              >
                <div className={`p-3 rounded-2xl ${options.maintenance ? 'bg-emerald-600 text-white' : 'bg-stone-100 text-stone-400'}`}>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                </div>
                <div>
                  <h4 className={`font-bold ${options.maintenance ? 'text-emerald-900' : 'text-stone-900'}`}>Pro Maintenance</h4>
                  <p className="text-xs text-stone-500 mt-1">Rp {PRICING_CONSTANTS.MAINTENANCE_FEE.toLocaleString()} / month</p>
                </div>
              </button>

              <button 
                onClick={() => toggleOption('warranty')}
                disabled={isSubmitting}
                className={`p-6 rounded-[2rem] border-2 transition-all text-left flex items-start gap-4 ${options.warranty ? 'bg-emerald-50 border-emerald-500' : 'border-stone-100 hover:border-emerald-200'}`}
              >
                <div className={`p-3 rounded-2xl ${options.warranty ? 'bg-emerald-600 text-white' : 'bg-stone-100 text-stone-400'}`}>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04M12 21a9.003 9.003 0 008.367-5.658M12 21a9.003 9.003 0 01-8.367-5.658M12 21c-4.97 0-9-4.03-9-9s4.03-9 9-9 9 4.03 9 9-4.03 9-9 9z" /></svg>
                </div>
                <div>
                  <h4 className={`font-bold ${options.warranty ? 'text-emerald-900' : 'text-stone-900'}`}>3-Month Warranty</h4>
                  <p className="text-xs text-stone-500 mt-1">Rp {PRICING_CONSTANTS.WARRANTY_FEE.toLocaleString()} / project</p>
                </div>
              </button>

              <button 
                onClick={() => toggleOption('installation')}
                disabled={isSubmitting}
                className={`p-6 rounded-[2rem] border-2 transition-all text-left flex items-start gap-4 ${options.installation ? 'bg-emerald-50 border-emerald-500' : 'border-stone-100 hover:border-emerald-200'}`}
              >
                <div className={`p-3 rounded-2xl ${options.installation ? 'bg-emerald-600 text-white' : 'bg-stone-100 text-stone-400'}`}>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                </div>
                <div>
                  <h4 className={`font-bold ${options.installation ? 'text-emerald-900' : 'text-stone-900'}`}>Full Installation</h4>
                  <p className="text-xs text-stone-500 mt-1">From Rp {PRICING_CONSTANTS.INSTALLATION_BASE.toLocaleString()}</p>
                </div>
              </button>
            </div>

            {options.shipping && (
              <div className="mt-8 pt-8 border-t border-stone-100 animate-in fade-in slide-in-from-top-2">
                <div className="flex justify-between items-center mb-4">
                  <label className="block text-sm font-bold text-stone-700">Distance to Delivery Site</label>
                  <span className="text-emerald-600 font-bold text-lg">{distance} km</span>
                </div>
                <input 
                  type="range" min="1" max="100" value={distance} 
                  disabled={isSubmitting}
                  onChange={(e) => setDistance(parseInt(e.target.value))}
                  className="w-full h-2 bg-stone-100 rounded-lg appearance-none cursor-pointer accent-emerald-600 disabled:opacity-50"
                />
                <p className="text-xs text-stone-400 mt-4 italic">
                  * Shipping fee is calculated at Rp {PRICING_CONSTANTS.SHIPPING_KM_RATE.toLocaleString()} per km.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Order Summary Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white p-8 rounded-[2.5rem] border border-stone-100 shadow-xl sticky top-32">
            <h3 className="text-2xl font-bold mb-8">Order Summary</h3>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-stone-600">
                <span>Items Subtotal</span>
                <span>Rp {cartTotal.toLocaleString()}</span>
              </div>
              
              {options.shipping && (
                <div className="flex justify-between text-stone-600">
                  <span>Shipping ({distance}km)</span>
                  <span>Rp {shippingFee.toLocaleString()}</span>
                </div>
              )}
              
              {options.maintenance && (
                <div className="flex justify-between text-stone-600">
                  <span>Maintenance Fee</span>
                  <span>Rp {PRICING_CONSTANTS.MAINTENANCE_FEE.toLocaleString()}</span>
                </div>
              )}
              
              {options.warranty && (
                <div className="flex justify-between text-stone-600">
                  <span>Extended Warranty</span>
                  <span>Rp {PRICING_CONSTANTS.WARRANTY_FEE.toLocaleString()}</span>
                </div>
              )}

              {options.installation && (
                <div className="flex justify-between text-stone-600">
                  <span>Installation</span>
                  <span>Rp {PRICING_CONSTANTS.INSTALLATION_BASE.toLocaleString()}</span>
                </div>
              )}
            </div>
            
            <div className="border-t border-stone-100 pt-6 mb-10">
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold">Total Amount</span>
                <span className="text-3xl font-bold text-emerald-600">Rp {grandTotal.toLocaleString()}</span>
              </div>
            </div>
            
            <button 
              onClick={handleCompleteOrder}
              disabled={isSubmitting}
              className="w-full py-5 bg-stone-900 hover:bg-emerald-600 text-white font-bold rounded-2xl shadow-xl transition-all mb-4 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Processing...
                </>
              ) : (
                'Complete Order'
              )}
            </button>
            <p className="text-center text-xs text-stone-400">Secure transaction powered by EmbunScape AI.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
