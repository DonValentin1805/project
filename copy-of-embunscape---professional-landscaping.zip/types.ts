
export interface Product {
  id: string;
  name: string;
  category: 'Plant' | 'Material' | 'Service';
  price: number;
  image: string;
  description: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface ServiceOptions {
  shipping: boolean;
  maintenance: boolean;
  warranty: boolean;
  installation: boolean;
}

export interface ProjectState {
  originalImage: string | null;
  designedImage: string | null;
  isDesigning: boolean;
  details: {
    areaSize: number;
    style: string;
  };
}

export const PRICING_CONSTANTS = {
  MAINTENANCE_FEE: 250000,
  WARRANTY_FEE: 150000,
  INSTALLATION_BASE: 500000,
  SHIPPING_KM_RATE: 15000,
};
